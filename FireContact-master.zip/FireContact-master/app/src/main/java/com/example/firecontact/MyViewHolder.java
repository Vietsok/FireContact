package com.example.firecontact;

import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class MyViewHolder extends RecyclerView.ViewHolder {
    TextView nom, mail, tel;
    ImageView avatar;

    public MyViewHolder(@NonNull View itemView) {
        /** Dans ce constructeur on fait le lien vers le design du layout d'une ligne du recycler **/
        super(itemView);
        avatar = itemView.findViewById(R.id.iv_avatar);
        nom = itemView.findViewById(R.id.tv_nom);
        mail = itemView.findViewById(R.id.tv_mail);
        tel = itemView.findViewById(R.id.tv_tel);
    }
}

